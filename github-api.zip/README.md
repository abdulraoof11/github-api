## How to start

Node version `18.17.1`
npm version `10.1.0`

First install all packages through `npm install` command.
Then start the project using `npm run dev` command.

## Functionalities

# API URL:

https://api.github.com/users

# Tasks accomplished:

1. Fetch users from given API
2. Preview users along with their complete details in cards in the grid styling, list sorted by 'login' field
3. 'Add' user button to add new user in a popup
4. Append newly created user to the existing list, still list be sorted by the 'login' field
5. Edit user field except 'login' name on user details page
6. Delete a user
7. Add search functionality to search a specific user within the list
